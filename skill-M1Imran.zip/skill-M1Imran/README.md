# Hello World Skill

## Usage:
* `hello world`
* `how are you`
* `thank you`
* `Rajni`
